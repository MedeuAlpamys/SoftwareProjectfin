package com.example.project;

import java.awt.*;
import java.io.File;
import java.io.IOException;

public class OpenPDFFile {
    public void open(String name){
        EBookOpener eBookOpener = new EBookOpener();
        BookInterface bookInterface = new Adapter(eBookOpener);
        bookInterface.execute(name);
    }
}
