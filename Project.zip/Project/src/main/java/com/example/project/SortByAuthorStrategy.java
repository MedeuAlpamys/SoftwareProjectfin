package com.example.project;

import com.example.project.Book;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortByAuthorStrategy implements Strategy{
    @Override
    public List<Book> execute(List<Book> bookshelf) {
        return bookshelf.stream()
                .sorted(Comparator.comparing(book -> book.author))
                .collect(Collectors.toList());
    }

    @Override
    public void add(List<Book> bookshelf, Book book) {
        if(!book.getAuthor().isBlank()) bookshelf.add(book);
    }
}
