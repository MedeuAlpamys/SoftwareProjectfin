package com.example.project;

import java.awt.*;
import java.io.File;
import java.io.IOException;

public class EBookOpener {
    public void open(String filePath) {
        try {
            File file = new File(filePath);
            if (file.exists()) {
                Desktop desktop = Desktop.getDesktop();
                desktop.open(file);
            } else {
                System.out.println("File does not exist: " + filePath);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}