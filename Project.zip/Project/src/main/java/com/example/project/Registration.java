package com.example.project;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.IOException;

public class Registration {
    @FXML
    private TextField LogIn;

    @FXML
    private PasswordField Password;
    @FXML
    protected void RegisterButtonClicked() throws IOException {
        HelloApplication.switchScene("Register.fxml");
    }
    @FXML
    protected void RegisterButtonClicked2() throws IOException {
        File usersFolder = new File("Uproject");
        if (!usersFolder.exists()) {
            usersFolder.mkdir();
        }
        if(LogIn.getText().trim().length() < 5 || LogIn.getText().isBlank()){
            String message = "Login should have at least 5 letters and without spaces!";
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Exception!");
            alert.setHeaderText("Exception!");
            alert.setContentText(message);
            alert.showAndWait();
        }else if(Password.getText().trim().length() < 8 || Password.getText().isBlank()){
            String message = "Password should have at least 8 letters and without spaces!";
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Exception!");
            alert.setHeaderText("Exception!");
            alert.setContentText(message);
            alert.showAndWait();
        }
        else {
            File userFile = new File(LogIn.getText() + ".prs");

            if (userFile.exists()) {
                String message = "User exists!";
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Exception!");
                alert.setHeaderText("Exception!");
                alert.setContentText(message);
                alert.showAndWait();
            } else {
                Person prstmp = new Person();
                prstmp.setName(LogIn.getText());
                prstmp.setPassword(Password.getText());
                prstmp.saveData("Uproject");
                HelloApplication.switchScene("Main.fxml");
            }
        }
    }
    @FXML
    protected void LoginButtonClicked() throws IOException {
        HelloApplication.switchScene("LogIn.fxml");
    }
    @FXML
    protected void backToMain() throws IOException {
        HelloApplication.switchScene("Main.fxml");
    }
}
