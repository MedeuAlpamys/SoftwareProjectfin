package com.example.project;

public interface BookInterface {
    void execute(String filepath);
}
