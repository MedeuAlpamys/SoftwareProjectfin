package com.example.project;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Map;

public class CreateBookshelfController {
    @FXML
    private TextField bookname;
    Bookshelf bookshelf = new Bookshelf();

    @FXML
    private ComboBox<String> sortingstrategy = new ComboBox<>();
    @FXML
    private TextArea BooksDisplay = new TextArea();

    private final Map<String, Strategy> sortingStrategies = new HashMap<>();
    public void initialize() {

        sortingStrategies.put("Literary_Fiction", new SortByLiteraryFictionGenreStrategy());
        sortingStrategies.put("Mystery", new SortByMysteryGenreStrategy());
        sortingStrategies.put("Thriller", new SortByThrillerGenreStrategy());
        sortingStrategies.put("Science_Fiction", new SortByScienceFictionGenreStrategy());
        sortingStrategies.put("Fantasy", new SortByFantasyGenreStrategy());
        sortingStrategies.put("Romance", new SortByRomanceGenreStrategy());
        sortingStrategies.put("Historical_Fiction", new SortByHistoricalFictionGenreStrategy());
        sortingStrategies.put("Horror", new SortByHorrorGenreStrategy());
        sortingStrategies.put("Poetry", new SortByPoetryGenreStrategy());
        sortingStrategies.put("Drama", new SortByDramaGenreStrategy());
        sortingStrategies.put("Children's_Literature", new SortByChildrensLiteratureGenreStrategy());
        sortingStrategies.put("Non_Fiction", new SortByNonFictionGenreStrategy());
        sortingStrategies.put("Author", new SortByAuthorStrategy());
        sortingStrategies.put("Award", new SortByAwardStrategy());
        sortingstrategy.getItems().addAll(sortingStrategies.keySet());
    }

    @FXML
    protected void add() {
        String selectedStrategy = sortingstrategy.getSelectionModel().getSelectedItem();

        if (selectedStrategy == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Exception!");
            alert.setHeaderText("Exception!");
            alert.setContentText("Set sorting Strategy!");
            alert.showAndWait();
            return;
        }

        Strategy strategy = sortingStrategies.get(selectedStrategy);
        File file = new File("Books", bookname.getText() + ".bib");

        if (file.exists()) {
            try (FileInputStream fileIn = new FileInputStream(file);
                 ObjectInputStream objectIn = new ObjectInputStream(fileIn)) {
                Book book = (Book) objectIn.readObject();
                bookshelf.setSortingStrategy(strategy);
                bookshelf.addBook(book);
                bookname.clear();

            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Exception!");
            alert.setHeaderText("Exception!");
            alert.setContentText("Book is not available!");
            alert.showAndWait();
        }
    }
    @FXML
    protected void displayBooks(){
        String bookshelfContent = bookshelf.getBooks();
        BooksDisplay.appendText(bookshelfContent);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText(bookshelfContent);
        alert.showAndWait();
    }

    @FXML
    protected void back() throws IOException {
        HelloApplication.switchScene("StaffMain.fxml");
    }
}
