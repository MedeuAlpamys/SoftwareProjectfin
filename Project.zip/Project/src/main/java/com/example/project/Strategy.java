package com.example.project;

import com.example.project.Book;

import java.util.List;

public interface Strategy {
    List<Book> execute(List<Book> bookshelf);
    void add(List<Book> bookshelf, Book book);
}
