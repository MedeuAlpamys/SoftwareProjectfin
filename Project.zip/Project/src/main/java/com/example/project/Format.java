package com.example.project;
public enum Format {
    Electronic, Printed, Audio, Online, Interactive, Braille, Large_Print, Graphic_Novels, Comics, Special, Educational, Serialized;
}
