package com.example.project;

import java.time.LocalDate;
import java.util.*;

public class BookBuilder implements Builder{
    private String electronicVersion = "";
    private String title = "";
    private String author = "";
    private boolean isInTheLibrary = false;
    private ISBN isbn = null;
    private String publisher = "";
    private LocalDate publicationDate = null;
    private Genre genre =Genre.Other;
    private long numberOfPages = 0;
    private boolean isAvailable = false;
    private double condition = 0;
    private String checker = null;
    private String user = null;
    private String language = "";
    private List<String> availableLanguages = null;
    private String summaryDescription = "";
    private Map<String, String> reviews = null;
    private String edition = "";
    private List<String> editions = null;
    private Format format = null;
    private List<String> series = null;
    private String part = "";
    private List<String> award = null;
    private List<String> tags = null;
    private List<String> recommendationAndRelated = null;
    private String copyrightInfo = "";
    private String additionalMaterials = "";
    private String donor = null;
    private String usageHistory = null;
    private Map<String, String> readerNotes = null;

    public BookBuilder(){
    }

    // BuilderSetters
    public BookBuilder setElectronicVersion(String electronicVersion) {
        this.electronicVersion = electronicVersion;
        return this;
    }

    public BookBuilder setTitle(String title) {
        this.title = title;
        return this;
    }

    public BookBuilder setAuthor(String author) {
        this.author = author;
        return this;
    }

    public BookBuilder setIsInTheLibrary(boolean isInTheLibrary) {
        this.isInTheLibrary = isInTheLibrary;
        return this;
    }

    public BookBuilder setIsbn(String isbn) {
        this.isbn = new ISBN(isbn);
        return this;
    }

    public BookBuilder setPublisher(String publisher) {
        this.publisher = publisher;
        return this;
    }

    public BookBuilder setPublicationDate(int year, int month, int day) {
        this.publicationDate = LocalDate.of(year, month, day);
        return this;
    }

    public BookBuilder setGenre(String genre) {
        this.genre = Genre.valueOf(genre);
        return this;
    }

    public BookBuilder setNumberOfPages(long numberOfPages) {
        this.numberOfPages = numberOfPages;
        return this;
    }

    public BookBuilder setAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
        return this;
    }

    public BookBuilder setCondition(double condition) {
        this.condition = condition;
        return this;
    }
    public BookBuilder setChecker(String checker) {
        this.checker = checker;
        return this;
    }

    public BookBuilder setUser(String user) {
        this.user = user;
        return this;
    }

    public BookBuilder setLanguage(String language) {
        this.language = language;
        return this;
    }

    public BookBuilder setAvailableLanguages(String languages) {
        String[] wordsArray = languages.split(",\\s*");
        this.availableLanguages = Arrays.asList(wordsArray);
        return this;
    }
    public BookBuilder setSummaryDescription(String summaryDescription) {
        this.summaryDescription = summaryDescription;
        return this;
    }

    public BookBuilder setReviews(String reviews) {
        Map<String, String> reviewstmp = new HashMap<>();
        String[] lines = reviews.split("\n");
        for (String line : lines) {
            String[] parts = line.split(":\\s", 2);
            if (parts.length == 2) {
                String author = parts[0];
                String description = parts[1];
                reviewstmp.put(author, description);
            }
        }
        this.reviews = reviewstmp;
        return this;
    }

    public BookBuilder setEdition(String edition) {
        this.edition = edition;
        return this;
    }

    public BookBuilder setEditions(String editions) {
        String[] wordsArray = editions.split(",\\s*");
        this.editions = Arrays.asList(wordsArray);
        return this;
    }
    public BookBuilder setFormat(Format format) {
        this.format =  (format);
        return this;
    }

    public BookBuilder setSeries(String series) {
        String[] wordsArray = series.split(",\\s*");
        this.series = Arrays.asList(wordsArray);
        return this;
    }

    public BookBuilder setPart(String part) {
        this.part = part;
        return this;
    }

    public BookBuilder setAward(String awards) {
        String[] wordsArray = awards.split(",\\s*");
        this.award = Arrays.asList(wordsArray);
        return this;
    }

    public BookBuilder setTags(String tags) {
        String[] wordsArray = tags.split(",\\s*");
        this.tags = Arrays.asList(wordsArray);
        return this;
    }

    public BookBuilder setRecommendationAndRelated(String recommendationAndRelated) {
        String[] wordsArray = recommendationAndRelated.split(",\\s*");
        this.recommendationAndRelated = Arrays.asList(wordsArray);
        return this;
    }

    public BookBuilder setCopyrightInfo(String copyrightInfo) {
        this.copyrightInfo = copyrightInfo;
        return this;
    }

    public BookBuilder setAdditionalMaterials(String additionalMaterials) {
        this.additionalMaterials = additionalMaterials;
        return this;
    }

    public BookBuilder setUsageHistory(String usageHistoryString) {
        this.usageHistory = usageHistoryString;
        return this;
    }

    public BookBuilder setDonor(String donor) {
        this.donor = donor;
        return this;
    }

    public BookBuilder setReaderNotes(String readerNotesString) {
        Map<String, String> notes = new HashMap<>();
        String[] lines = readerNotesString.split("\n");
        for (String line : lines) {
            String[] parts = line.split(":\\s", 2);
            if (parts.length == 2) {
                String author = parts[0];
                String description = parts[1];
                notes.put(author, description);
            }
        }
        this.readerNotes = notes;
        return this;
    }
    public Book build() {
        return new Book(electronicVersion, title, author, isInTheLibrary, isbn, publisher, publicationDate, genre,
                numberOfPages, isAvailable, condition, checker, user, language,
                availableLanguages, summaryDescription, reviews, edition, editions, format, series,
                part, award, tags, recommendationAndRelated, copyrightInfo, additionalMaterials,
                donor, usageHistory, readerNotes);
    }
    public void reset() {
        String electronicVersion = "";
        String title = "";
        String author = "";
        boolean isInTheLibrary = false;
        ISBN isbn = null;
        String publisher = "";
        LocalDate publicationDate = null;
        Genre genre = null;
        long numberOfPages = 0;
        boolean isAvailable = false;
        double condition = 0;
        String checker = null;
        String user = null;
        String language = "";
        List<String> availableLanguages = null;
        String summaryDescription = "";
        Map<String, String> reviews = null;
        String edition = "";
        List<String> editions = null;
        Format format = null;
        List<String> series = null;
        String part = "";
        List<String> award = null;
        List<String> tags = null;
        List<String> recommendationAndRelated = null;
        String copyrightInfo = "";
        String additionalMaterials = "";
        boolean relevanceToCurriculum = false;
        String donor = null;
        String usageHistory = null;
        Map<String, String> readerNotes = null;
    }
}
