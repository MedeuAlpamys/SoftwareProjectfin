package com.example.project;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class EditBookController {
    @FXML
    private TextField DonorName;

    @FXML
    private TextField ElectronicVersion;

    @FXML
    private TextField ISBN;

    @FXML
    private TextField NumberOfPages;

    @FXML
    private TextField PublicationDate;

    @FXML
    private TextField Publisher;

    @FXML
    private TextField RecommendationAndRelated;

    @FXML
    private TextField Review;

    @FXML
    private TextField additionalMaterials;

    @FXML
    private TextField author;

    @FXML
    private TextField availableLanguage;

    @FXML
    private TextField award;

    @FXML
    private TextField bookName;

    @FXML
    private TextField checker;

    @FXML
    private ComboBox<String> condition = new ComboBox<>();

    @FXML
    private TextField copyrightInfo;

    @FXML
    private ComboBox<String> format = new ComboBox<>();

    @FXML
    private ComboBox<String> genre = new ComboBox<>();

    @FXML
    private TextField language;

    @FXML
    private TextField part;

    @FXML
    private TextField readerNotes;

    @FXML
    private TextField reviews;

    @FXML
    private TextField series;

    @FXML
    private TextField summaryDescription;

    @FXML
    private TextField tags;
    BookBuilder bookBuilder = new BookBuilder();
    @FXML
    public void initialize() {
        genre.getItems().addAll(
                "Literary_Fiction", "Mystery", "Thriller", "Science_Fiction", "Fantasy", "Romance",
                "Historical_Fiction", "Horror", "Poetry", "Drama", "Children's_Literature", "Non_Fiction"
        );
        condition.getItems().addAll("100", "90", "80", "70", "60", "50", "40", "30", "20", "10");
        format.getItems().addAll("Electronic", "Printed", "Audio", "Online", "Interactive", "Braille", "Large_Print", "Graphic_Novels", "Comics", "Special", "Educational", "Serialized");
    }
    @FXML
    public void saveBook() {
        for (int i = 0; i <= 24; i++) {
            switch (i) {
                case 0:
                    if (!checkNull(DonorName.getText())) {
                        bookBuilder.setDonor(DonorName.getText());
                    }
                    break;
                case 1:
                    if (!checkNull(ElectronicVersion.getText())) {
                        bookBuilder.setElectronicVersion(ElectronicVersion.getText());
                    }
                    break;
                case 2:
                    if (!checkNull(ISBN.getText())) {
                        bookBuilder.setIsbn(ISBN.getText());
                    }
                    break;
                case 3:
                    if (!checkNull(NumberOfPages.getText())) {
                        bookBuilder.setNumberOfPages(Long.parseLong( NumberOfPages.getText()));
                    }
                    break;
                case 4:
                    if (!checkNull(PublicationDate.getText())) {
                        String pub = PublicationDate.getText();
                        ArrayList<Integer> arr = new ArrayList<>();
                        String s = "";
                        for (int j = 0; j < pub.length(); j++) {
                            if(pub.charAt(j) != '-'){
                                s += pub.charAt(j);
                            }else{
                                arr.add(Integer.parseInt(s));
                                s = "";
                            }
                        }
                        arr.add(Integer.parseInt(s));

                        bookBuilder.setPublicationDate(arr.get(0), arr.get(1), arr.get(2));
                    }
                    break;
                case 5:
                    if (!checkNull(Publisher.getText())) {
                        bookBuilder.setPublisher(Publisher.getText());
                    }
                    break;
                case 6:
                    if (!checkNull(author.getText())) {
                        bookBuilder.setAuthor(author.getText());
                    }
                    break;
                case 7:
                    String selectedCondition = condition.getSelectionModel().getSelectedItem();
                    if (selectedCondition != null) {
                        bookBuilder.setCondition(Double.parseDouble(selectedCondition));
                    }
                    break;
                case 8:
                    String selectedFormat = format.getSelectionModel().getSelectedItem();
                    if (selectedFormat != null) {
                        bookBuilder.setFormat(Format.valueOf(selectedFormat));
                    }
                    break;
                case 9:
                    String selectedGenre = genre.getSelectionModel().getSelectedItem();
                    if (selectedGenre != null) {
                        bookBuilder.setGenre(selectedGenre);
                    }
                    break;
                case 10:
                    if (!checkNull(bookName.getText())) {
                        bookBuilder.setTitle(bookName.getText());
                    }
                    break;
                case 11:
                    if (!checkNull(Review.getText())) {
                        bookBuilder.setReviews(Review.getText());
                    }
                    break;
                case 12:
                    if (!checkNull(language.getText())) {
                        bookBuilder.setLanguage(language.getText());
                    }
                    break;
                case 13:
                    if (!checkNull(availableLanguage.getText())) {
                        bookBuilder.setAvailableLanguages(availableLanguage.getText());
                    }
                    break;
                case 14:
                    if (!checkNull(part.getText())) {
                        bookBuilder.setPart(part.getText());
                    }
                    break;
                case 15:
                    if (!checkNull(tags.getText())) {
                        bookBuilder.setTags(tags.getText());
                    }
                    break;
                case 16:
                    if (!checkNull(series.getText())) {
                        bookBuilder.setSeries(series.getText());
                    }
                    break;
                case 17:
                    if (!checkNull(checker.getText())) {
                        bookBuilder.setChecker(checker.getText());
                    }
                    break;
                case 18:
                    if(!checkNull(summaryDescription.getText())){
                        bookBuilder.setSummaryDescription(summaryDescription.getText());
                    }
                    break;
                case 19:
                    if(!checkNull(reviews.getText())){
                        bookBuilder.setReviews(reviews.getText());
                    }
                    break;
                case 20:
                    if(!checkNull(award.getText())){
                        bookBuilder.setAward(award.getText());
                    }
                    break;
                case 21:
                    if(!checkNull(RecommendationAndRelated.getText())){
                        bookBuilder.setRecommendationAndRelated(RecommendationAndRelated.getText());
                    }
                    break;
                case 22:
                    if(!checkNull(copyrightInfo.getText())){
                        bookBuilder.setCopyrightInfo(copyrightInfo.getText());
                    }
                    break;
                case 23:
                    if(!checkNull(additionalMaterials.getText())){
                        bookBuilder.setAdditionalMaterials(additionalMaterials.getText());
                    }
                    break;
                case 24:
                    if(!checkNull(readerNotes.getText())){
                        bookBuilder.setReaderNotes(readerNotes.getText());
                    }
                    break;
                default:
                    break;
            }
        }
        bookBuilder.setIsInTheLibrary(true);
        Book book = bookBuilder.build();
        book.saveThisBook();
        bookBuilder.reset();
    }
    public boolean checkNull(Object object){
        return object == null || object == "";
    }

    @FXML
    public void reset(){
        checker.clear();
        DonorName.clear();
        ElectronicVersion.clear();
        ISBN.clear();
        NumberOfPages.clear();
        PublicationDate.clear();
        Publisher.clear();
        author.clear();
        condition.getEditor().clear();
        format.getEditor().clear();
        genre.getEditor().clear();
        bookName.clear();
        Review.clear();
        language.clear();
        availableLanguage.clear();
        part.clear();
        tags.clear();
        series.clear();
        summaryDescription.clear();
        reviews.clear();
        RecommendationAndRelated.clear();
        award.clear();
        copyrightInfo.clear();
        additionalMaterials.clear();
        readerNotes.clear();
    }
    @FXML
    protected void back() throws IOException {
        HelloApplication.switchScene("StaffMain.fxml");
    }
}
