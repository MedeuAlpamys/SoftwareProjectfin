package com.example.project;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Objects;

public class StaffLogInController {

    @FXML
    private TextField staffName;

    @FXML
    private PasswordField staffPassword;
    @FXML
    protected void backToMain() throws IOException {
        HelloApplication.switchScene("Main.fxml");
    }
    @FXML
    protected void LoginButtonClicked() throws IOException {
        File file = new File("Staff", staffName.getText() + ".prs");
        Person prs = null;
        if(staffName.getText().trim().isBlank()){
            displayErrorMessage("Fill Staff Name field!");
        }else if (file.exists()) {
            try (FileInputStream fileIn = new FileInputStream(file);
                 ObjectInputStream objectIn = new ObjectInputStream(fileIn)) {
                prs = (Person) objectIn.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
            assert prs != null;
            if (Objects.equals(prs.getPassword(), staffPassword.getText())) {
                HelloApplication.switchScene("StaffMain.fxml");
            } else {
                displayErrorMessage("Wrong Password!");
            }
        } else {
            displayErrorMessage("User doesn't exist!");
        }
    }
    @FXML
    protected void addBook() throws IOException{
        HelloApplication.switchScene("AddBook.fxml");
    }
    @FXML
    protected void CreateBookshelf() throws IOException {
        HelloApplication.switchScene("CreateBookshelf.fxml");
    }
    private void displayErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Exception!");
        alert.setHeaderText("Exception!");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
