package com.example.project;

public interface Builder {

    public Book build();
}
