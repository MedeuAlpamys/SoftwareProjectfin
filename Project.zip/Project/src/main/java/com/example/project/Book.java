package com.example.project;

import java.io.*;
import java.time.*;
import java.util.List;
import java.util.Map;

public class Book implements Serializable {
    String electronicVersion = "";
    String title = "";
    String author = null;
    boolean isInTheLibrary = false;
    ISBN isbn = null;
    String publisher= "";
    LocalDate publicationDate= null;
    Genre genre= Genre.Other;
    long bookID= 0;
    long numberOfPages= 0;
    boolean isAvailable = false;
    String bookLocation = null;
    double condition = 0;
    String checker = null;
    String user = null;
    String language = "";
    List<String> availableLanguages = null;
    String summaryDescription = "";
    Map<String, String> reviews = null;
    String edition = "";
    List<String> editions = null;
    Format format = null;
    List<String> series = null;
    String part = "";
    List<String> award = null;
    List<String> tags = null;
    List<String> recommendationAndRelated = null;
    String copyrightInfo = "";
    String additionalMaterials = "";
    String donor = null;
    String usageHistory = "";
    Map<String, String> readerNotes = null;
    public Book(String electronicVersion, String title, String author, boolean isInTheLibrary, ISBN isbn, String publisher,
                LocalDate publicationDate, Genre genre, long numberOfPages,
                boolean isAvailable, double condition, String checker,
                String user, String language, List<String> availableLanguages, String summaryDescription,
                Map<String, String> reviews, String edition, List<String> editions, Format format,
                List<String> series, String part, List<String> award, List<String> tags,
                List<String> recommendationAndRelated, String copyrightInfo, String additionalMaterials,
                String donor, String usageHistory,
                Map<String, String> readerNotes) {
        this.electronicVersion = electronicVersion;
        this.title = title;
        this.author = author;
        this.isInTheLibrary = isInTheLibrary;
        this.isbn = isbn;
        this.publisher = publisher;
        this.publicationDate = publicationDate;
        this.genre = genre;
        this.bookID = toIndex();
        this.numberOfPages = numberOfPages;
        this.isAvailable = isAvailable;
        this.bookLocation = bookLocation;
        this.condition = condition;
        this.checker = checker;
        this.user = user;
        this.language = language;
        this.availableLanguages = availableLanguages;
        this.summaryDescription = summaryDescription;
        this.reviews = reviews;
        this.edition = edition;
        this.editions = editions;
        this.format = format;
        this.series = series;
        this.part = part;
        this.award = award;
        this.tags = tags;
        this.recommendationAndRelated = recommendationAndRelated;
        this.copyrightInfo = copyrightInfo;
        this.additionalMaterials = additionalMaterials;
        this.donor = donor;
        this.usageHistory = usageHistory;
        this.readerNotes = readerNotes;
    }
    public Book(){

    }
    public int toIndex(){
        for (int i = 0; i < Long.MAX_VALUE; i++) {
            File file = new File(i+".bib");
            if (!file.exists()) {
                return i;
            }
        }
        return 1;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public boolean isInTheLibrary() {
        return isInTheLibrary;
    }

    public ISBN getIsbn() {
        return isbn;
    }

    public String getPublisher() {
        return publisher;
    }

    public LocalDate getPublicationDate() {
        return publicationDate;
    }

    public Genre getGenre() {
        return genre;
    }

    public long getBookID() {
        return bookID;
    }

    public long getNumberOfPages() {
        return numberOfPages;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public String getBookLocation() {
        return bookLocation;
    }

    public double getCondition() {
        return condition;
    }

    public String getChecker() {
        return checker;
    }

    public String getUser() {
        return user;
    }

    public String getLanguage() {
        return language;
    }

    public List<String> getAvailableLanguages() {
        return availableLanguages;
    }

    public String getSummaryDescription() {
        return summaryDescription;
    }

    public Map<String, String> getReviews() {
        return reviews;
    }

    public String getEdition() {
        return edition;
    }

    public List<String> getEditions() {
        return editions;
    }

    public Format getFormat() {
        return format;
    }

    public List<String> getSeries() {
        return series;
    }

    public String getPart() {
        return part;
    }

    public List<String> getAward() {
        return award;
    }

    public List<String> getTags() {
        return tags;
    }

    public List<String> getRecommendationAndRelated() {
        return recommendationAndRelated;
    }

    public String getCopyrightInfo() {
        return copyrightInfo;
    }

    public String getAdditionalMaterials() {
        return additionalMaterials;
    }

    public String getDonor() {
        return donor;
    }

    public String getUsageHistory() {
        return usageHistory;
    }

    public Map<String, String> getReaderNotes() {
        return readerNotes;
    }
    public void openElectronicVersion(){
        EBookOpener eBookOpener = new EBookOpener();
        BookInterface bookInterface = new Adapter(eBookOpener);
        bookInterface.execute(electronicVersion);
    }
    public void ReaderGotFromLibrary(String usageHistoryString) {
        this.usageHistory += "\n" + usageHistoryString;
    }
    public void saveThisBook(){
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Books/" + getTitle()+ ".bib"))) {
            oos.writeObject(this);
            System.out.println("Book saved to file successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
