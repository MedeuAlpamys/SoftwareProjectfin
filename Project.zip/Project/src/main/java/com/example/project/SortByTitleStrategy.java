package com.example.project;

import com.example.project.Book;
import com.example.project.Strategy;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortByTitleStrategy implements Strategy {
    @Override
    public List<Book> execute(List<Book> books) {
        return books.stream()
                .sorted(Comparator.comparing(Book::getTitle))
                .collect(Collectors.toList());
    }

    @Override
    public void add(List<Book> bookshelf, Book book) {
        if(!book.getTitle().isBlank()) bookshelf.add(book);
    }
}
