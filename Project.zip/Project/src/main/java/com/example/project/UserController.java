package com.example.project;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.*;
import java.util.*;

public class UserController {
    BookBuilder bookBuilder = new BookBuilder();
    @FXML
    private TextField bookname;

    @FXML
    private TextField BookNameForPDF;
    @FXML
    private TextField DonorName;

    @FXML
    private TextField ElectronicVersion;

    @FXML
    private TextField ISBN;

    @FXML
    private TextField NumberOfPages;

    @FXML
    private TextField PublicationDate;

    @FXML
    private TextField Publisher;

    @FXML
    private TextField authorField;

    @FXML
    private ComboBox<String> condition = new ComboBox<>();

    @FXML
    private ComboBox<String> format = new ComboBox<>();

    @FXML
    private ComboBox<String> genre = new ComboBox<>();

    @FXML
    private TextField nameField;
    @FXML
    private TextField Review;
    @FXML
    private TextField language;
    @FXML
    private TextField availableLanguage;
    @FXML
    private TextField part;
    @FXML
    private TextField tags;
    @FXML
    private TextField series;
    @FXML
    private TextField checker;
    @FXML
    private TextField summaryDescription;
    @FXML
    private TextField reviews;
    @FXML
    private TextField award;
    @FXML
    private TextField RecommendationAndRelated;
    @FXML
    private TextField copyrightInfo;
    @FXML
    private TextField additionalMaterials;
    @FXML
    private TextField readerNotes;
    @FXML
    private TextField Username;

    @FXML
    private TextField nameOfTheBook;

    @FXML
    public void initialize() {
        genre.getItems().addAll(
                "Literary_Fiction", "Mystery", "Thriller", "Science_Fiction", "Fantasy", "Romance",
                "Historical_Fiction", "Horror", "Poetry", "Drama", "Children's_Literature", "Non_Fiction"
        );
        condition.getItems().addAll("100", "90", "80", "70", "60", "50", "40", "30", "20", "10");
        format.getItems().addAll("Electronic", "Printed", "Audio", "Online", "Interactive", "Braille", "Large_Print", "Graphic_Novels", "Comics", "Special", "Educational", "Serialized");
    }
    @FXML
    public void DonateBook() throws IOException {
        HelloApplication.switchScene("DonateBook.fxml");
    }
    @FXML
    public void saveBook() {
        for (int i = 0; i <= 24; i++) {
            switch (i) {
                case 0:
                    if (!checkNull(DonorName.getText())) {
                        bookBuilder.setDonor(DonorName.getText());
                    }
                    break;
                case 1:
                    if (!checkNull(ElectronicVersion.getText())) {
                        bookBuilder.setElectronicVersion(ElectronicVersion.getText());
                    }
                    break;
                case 2:
                    if (!checkNull(ISBN.getText())) {
                        bookBuilder.setIsbn(ISBN.getText());
                    }
                    break;
                case 3:
                    if (!checkNull(NumberOfPages.getText())) {
                        bookBuilder.setNumberOfPages(Long.parseLong( NumberOfPages.getText()));
                    }
                    break;
                case 4:
                    if (!checkNull(PublicationDate.getText())) {
                        String pub = PublicationDate.getText();
                        ArrayList<Integer> arr = new ArrayList<>();
                        String s = "";
                        for (int j = 0; j < pub.length(); j++) {
                            if(pub.charAt(j) != '-'){
                                s += pub.charAt(j);
                            }else{
                                arr.add(Integer.parseInt(s));
                                s = "";
                            }
                        }
                        arr.add(Integer.parseInt(s));

                        bookBuilder.setPublicationDate(arr.get(0), arr.get(1), arr.get(2));
                    }
                    break;
                case 5:
                    if (!checkNull(Publisher.getText())) {
                        bookBuilder.setPublisher(Publisher.getText());
                    }
                    break;
                case 6:
                    if (!checkNull(authorField.getText())) {
                        bookBuilder.setAuthor(authorField.getText());
                    }
                    break;
                case 7:
                    String selectedCondition = condition.getSelectionModel().getSelectedItem();
                    if (selectedCondition != null) {
                        bookBuilder.setCondition(Double.parseDouble(selectedCondition));
                    }
                    break;
                case 8:
                    String selectedFormat = format.getSelectionModel().getSelectedItem();
                    if (selectedFormat != null) {
                        bookBuilder.setFormat(Format.valueOf(selectedFormat));
                    }
                    break;
                case 9:
                    String selectedGenre = genre.getSelectionModel().getSelectedItem();
                    if (selectedGenre != null) {
                        bookBuilder.setGenre(selectedGenre);
                    }
                    break;
                case 10:
                    if (!checkNull(nameField.getText())) {
                        bookBuilder.setTitle(nameField.getText());
                    }
                    break;
                case 11:
                    if (!checkNull(Review.getText())) {
                        bookBuilder.setReviews(Review.getText());
                    }
                    break;
                case 12:
                    if (!checkNull(language.getText())) {
                        bookBuilder.setLanguage(language.getText());
                    }
                    break;
                case 13:
                    if (!checkNull(availableLanguage.getText())) {
                        bookBuilder.setAvailableLanguages(availableLanguage.getText());
                    }
                    break;
                case 14:
                    if (!checkNull(part.getText())) {
                        bookBuilder.setPart(part.getText());
                    }
                    break;
                case 15:
                    if (!checkNull(tags.getText())) {
                        bookBuilder.setTags(tags.getText());
                    }
                    break;
                case 16:
                    if (!checkNull(series.getText())) {
                        bookBuilder.setSeries(series.getText());
                    }
                    break;
                case 17:
                    if (!checkNull(checker.getText())) {
                        bookBuilder.setChecker(checker.getText());
                    }
                    break;
                case 18:
                    if(!checkNull(summaryDescription.getText())){
                        bookBuilder.setSummaryDescription(summaryDescription.getText());
                    }
                    break;
                case 19:
                    if(!checkNull(reviews.getText())){
                        bookBuilder.setReviews(reviews.getText());
                    }
                    break;
                case 20:
                    if(!checkNull(award.getText())){
                        bookBuilder.setAward(award.getText());
                    }
                    break;
                case 21:
                    if(!checkNull(RecommendationAndRelated.getText())){
                        bookBuilder.setRecommendationAndRelated(RecommendationAndRelated.getText());
                    }
                    break;
                case 22:
                    if(!checkNull(copyrightInfo.getText())){
                        bookBuilder.setCopyrightInfo(copyrightInfo.getText());
                    }
                    break;
                case 23:
                    if(!checkNull(additionalMaterials.getText())){
                        bookBuilder.setAdditionalMaterials(additionalMaterials.getText());
                    }
                    break;
                case 24:
                    if(!checkNull(readerNotes.getText())){
                        bookBuilder.setReaderNotes(readerNotes.getText());
                    }
                    break;
                default:
                    break;
            }
        }
        bookBuilder.setIsInTheLibrary(true);
        Book book = bookBuilder.build();
        book.saveThisBook();
        bookBuilder.reset();
    }

    public boolean checkNull(Object object){
        return object == null || object == "";
    }
    @FXML
    public void readOnPDF() throws IOException {
        HelloApplication.switchScene("ReadOnPDF.fxml");
    }
    @FXML
    public void takeBook() throws IOException{
        HelloApplication.switchScene("TakeBook.fxml");
    }
    @FXML
    public void returnBook() throws IOException{
        HelloApplication.switchScene("ReturnBook.fxml");
    }
    @FXML
    public void searchBook() throws IOException{
        HelloApplication.switchScene("SearchBook.fxml");
    }
    @FXML
    protected void search(){
        File folder = new File("Books");
        File[] listOfFiles = folder.listFiles();

        if (listOfFiles != null) {
            boolean bookExists = false;
            for (File file : listOfFiles) {
                if (file.isFile() && file.getName().equals(bookname.getText() + ".bib")) {
                    bookExists = true;
                    break;
                }
            }

            if (bookExists) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Book");
                alert.setHeaderText(null);
                alert.setContentText("Book is on the Library!");
                alert.show();
            } else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Book");
                alert.setHeaderText(null);
                alert.setContentText("Book is not on the Library!");
                alert.show();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Folder 'Books' does not exist or is empty!");
            alert.show();
        }

    }
    @FXML
    protected void takeBookFromLibrary() {
        String username = Username.getText().trim();

        if (username.isBlank()) {
            displayErrorMessage("Fill Username field!");
            return;
        }

        Person user = getUser(username);

        if (user != null) {
            File bookFile = new File("Books", nameOfTheBook.getText() + ".bib");
            if (bookFile.exists()) {
                try (ObjectInputStream objectIn = new ObjectInputStream(new FileInputStream(bookFile))) {
                    Book book = (Book) objectIn.readObject();
                    user.toRead(book);
                    user.saveData("Uproject");
                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                }
            } else {
                displayErrorMessage("Book doesn't exist in the library!");
            }
        } else {
            displayErrorMessage("User doesn't exist!");
        }
    }
    @FXML
    private TextField Username1;

    @FXML
    private TextField nameOfTheBook1;
    @FXML
    protected void returnBookToLibrary() {
        Person user = getUser(Username1.getText().trim());

        if (user != null) {
            List<Book> readBooks = user.getReadBooks();

            for (Book book : readBooks) {
                if (book.getTitle().equals(nameOfTheBook1.getText())) {
                    readBooks.remove(book);
                    user.setReadBooks(readBooks);
                    user.saveData("Uproject");

                    File bookFile = new File("Books", nameOfTheBook1.getText() + ".bib");
                    if (bookFile.exists()) {
                        try (ObjectOutputStream objectOut = new ObjectOutputStream(new FileOutputStream(bookFile))) {
                            objectOut.writeObject(book);
                            System.out.println("Book returned to the library.");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                }
            }
        } else {
            displayErrorMessage("User doesn't exist!");
        }
    }


    private Person getUser(String username) {
        File file = new File("Uproject", username + ".prs");
        if (file.exists()) {
            try (ObjectInputStream objectIn = new ObjectInputStream(new FileInputStream(file))) {
                return (Person) objectIn.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
    @FXML
    public void openPDF(){
        EBookOpener eBookOpener = new EBookOpener();
        BookInterface bookInterface = new Adapter(eBookOpener);
        bookInterface.execute(BookNameForPDF.getText());
    }
    @FXML
    public void reset(){
        checker.clear();
        DonorName.clear();
        ElectronicVersion.clear();
        ISBN.clear();
        NumberOfPages.clear();
        PublicationDate.clear();
        Publisher.clear();
        authorField.clear();
        condition.getEditor().clear();
        format.getEditor().clear();
        genre.getEditor().clear();
        nameField.clear();
        Review.clear();
        language.clear();
        availableLanguage.clear();
        part.clear();
        tags.clear();
        series.clear();
        summaryDescription.clear();
        reviews.clear();
        RecommendationAndRelated.clear();
        award.clear();
        copyrightInfo.clear();
        additionalMaterials.clear();
        readerNotes.clear();
    }
    private void displayErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Exception!");
        alert.setHeaderText("Exception!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    protected void back() throws IOException {
        HelloApplication.switchScene("User.fxml");
    }
}
