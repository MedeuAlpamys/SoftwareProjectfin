package com.example.project;
import java.util.ArrayList;
import java.util.List;

public class Bookshelf {
    private List<Book> books;

    private Strategy sortingStrategy;

    public Bookshelf() {
        this.books = new ArrayList<>();
    }
    public void setSortingStrategy(Strategy sortingStrategy) {
        this.sortingStrategy = sortingStrategy;
    }
    public void addBook(Book book){
        sortingStrategy.add(books, book);
    }
    public String getBooks(){
        String s = "";
        int i = 1;
        for(Book book : books){
            s += i + ". " + book.getTitle();
            s += " by ";
            s += book.getAuthor() +"\n";
            i++;
        }
        return s;
    }
}