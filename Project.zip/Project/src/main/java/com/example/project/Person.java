package com.example.project;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Person implements Serializable {
    private String name;
    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public List<Book> getReadBooks() {
        return readBooks;
    }

    public void setReadBooks(List<Book> readBooks) {
        this.readBooks = readBooks;
    }

    private String password;
    public List<Book> readBooks = new ArrayList<>();
    public void saveData(String message){
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(message + "/"+name+".prs"))) {
            oos.writeObject(this);
            System.out.println("User saved to file successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void toRead(Book book){
        readBooks.add(book);
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}