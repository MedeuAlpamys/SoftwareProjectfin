
package com.example.project;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortByPoetryGenreStrategy implements Strategy{
    @Override
    public List<Book> execute(List<Book> bookshelf) {
        return bookshelf.stream()
                .sorted(Comparator.comparing(book -> book.genre.toString()))
                .collect(Collectors.toList());
    }
    @Override
    public void add(List<Book> bookshelf, Book book) {
        if(book.genre==Genre.Poetry) bookshelf.add(book);
    }
}
