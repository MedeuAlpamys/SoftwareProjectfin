package com.example.project;

public class Main {
    public static void main(String[] args) {
        BookBuilder bookBuilder = new BookBuilder();

        Book book1 = bookBuilder
                .setTitle("To Kill a Mockingbird")
                .setAuthor("Harper Lee")
                .setIsInTheLibrary(true)
                .setIsbn("978-006-11-200-84")
                .setPublisher("Harper Perennial Modern Classics")
                .setPublicationDate(1960, 7, 11)
                .setGenre("Literary_Fiction")
                .setNumberOfPages(281)
                .setAvailable(true)
                .setCondition(4.8)
                .setChecker("Library Staff 1")
                .setUser("Library Patron 1")
                .setLanguage("English")
                .setSummaryDescription("A novel set in the American South during the 1930s")
                .setEdition("50th Anniversary Edition")
                .setFormat(Format.Printed)
                .setTags("Classic, Legal drama")
                .build();

        Book book2 = bookBuilder
                .setTitle("1984")
                .setAuthor("George Orwell")
                .setIsInTheLibrary(true)
                .setIsbn("9780-451-52-493-5")
                .setPublisher("Signet Classics")
                .setPublicationDate(1949, 6, 8)
                .setGenre("Non_Fiction")
                .setNumberOfPages(328)
                .setAvailable(true)
                .setCondition(4.6)
                .setChecker("Library Staff 2")
                .setUser("Library Patron 2")
                .setLanguage("English")
                .setSummaryDescription("A totalitarian regime, propaganda, and surveillance")
                .setEdition("Signet Classics Edition")
                .setFormat(Format.Special)
                .setTags("Classic, Political fiction")
                .build();

        book1.saveThisBook();
        book2.saveThisBook();

        // Print details of the created books
        System.out.println("Created Book 1: " + book1.getTitle() + ", Author: " + book1.getAuthor());
        System.out.println("Created Book 2: " + book2.getTitle() + ", Author: " + book2.getAuthor());
    }
}