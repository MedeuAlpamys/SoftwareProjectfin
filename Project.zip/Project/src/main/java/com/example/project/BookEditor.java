package com.example.project;
import java.time.LocalDate;
import java.util.*;

public class BookEditor implements Builder {

    public Book bookToEdit = new Book();
    private String electronicVersion = "";
    private String title = "";
    private String author = "";
    private boolean isInTheLibrary = false;
    private ISBN isbn = null;
    private String publisher = "";
    private LocalDate publicationDate = null;
    private Genre genre = null;
    private long bookID = -1;
    private long numberOfPages = 0;
    private boolean isAvailable = false;
    private double condition = 0;
    private String checker = null;
    private String user = null;
    private String language = "";
    private List<String> availableLanguages = null;
    private String summaryDescription = "";
    private Map<String, String> reviews = null;
    private String edition = "";
    private List<String> editions = null;
    private Format format = null;
    private List<String> series = null;
    private String part = "";
    private List<String> award = null;
    private List<String> tags = null;
    private List<String> recommendationAndRelated = null;
    private String copyrightInfo = "";
    private String additionalMaterials = "";
    private String donor = null;
    private String usageHistory = null;
    private Map<String, String> readerNotes = null;

    public BookEditor() {
        // Default constructor
    }
    public BookEditor(Book inputBook) {
        this.electronicVersion = inputBook.electronicVersion;
        this.title = inputBook.title;
        this.author = inputBook.author;
        this.isInTheLibrary = inputBook.isInTheLibrary;
        this.isbn = inputBook.isbn;
        this.publisher = inputBook.publisher;
        this.publicationDate = inputBook.publicationDate;
        this.genre = inputBook.genre;
        this.bookID = inputBook.bookID;
        this.numberOfPages = inputBook.numberOfPages;
        this.isAvailable = inputBook.isAvailable;
        this.condition = inputBook.condition;
        this.checker = inputBook.checker;
        this.user = inputBook.user;
        this.language = inputBook.language;
        this.availableLanguages = inputBook.availableLanguages;
        this.summaryDescription = inputBook.summaryDescription;
        this.reviews = inputBook.reviews;
        this.edition = inputBook.edition;
        this.editions = inputBook.editions;
        this.format = inputBook.format;
        this.series = inputBook.series;
        this.part = inputBook.part;
        this.award = inputBook.award;
        this.tags = inputBook.tags;
        this.recommendationAndRelated = inputBook.recommendationAndRelated;
        this.copyrightInfo = inputBook.copyrightInfo;
        this.additionalMaterials = inputBook.additionalMaterials;
        this.donor = inputBook.donor;
        this.usageHistory = inputBook.usageHistory;
        this.readerNotes = inputBook.readerNotes;
    }

    // BuilderSetters

    public BookEditor setElectronicVersion(String electronicVersion) {
        this.electronicVersion = electronicVersion;
        return this;
    }
    public BookEditor setTitle(String title) {
        this.title = title;
        return this;
    }

    public BookEditor setAuthor(String author) {
        this.author = author;
        return this;
    }

    public BookEditor setIsInTheLibrary(boolean isInTheLibrary) {
        this.isInTheLibrary = isInTheLibrary;
        return this;
    }

    public BookEditor setIsbn(String isbn) {
        this.isbn = new ISBN(isbn);
        return this;
    }

    public BookEditor setPublisher(String publisher) {
        this.publisher = publisher;
        return this;
    }

    public BookEditor setPublicationDate(int year, int month, int day) {
        this.publicationDate = LocalDate.of(year, month, day);
        return this;
    }

    public BookEditor setGenre(String genre) {
        this.genre = Genre.valueOf(genre);
        return this;
    }

    public BookEditor setBookID(long bookID) {
        this.bookID = bookID;
        return this;
    }

    public BookEditor setNumberOfPages(long numberOfPages) {
        this.numberOfPages = numberOfPages;
        return this;
    }

    public BookEditor setAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
        return this;
    }
    public BookEditor setCondition(double condition) {
        this.condition = condition;
        return this;
    }
    public BookEditor setChecker(String checker) {
        this.checker = checker;
        return this;
    }

    public BookEditor setUser(String user) {
        this.user = user;
        return this;
    }

    public BookEditor setLanguage(String language) {
        this.language = language;
        return this;
    }

    public BookEditor setAvailableLanguages(String languages) {
        String[] wordsArray = languages.split(",\\s*");
        this.availableLanguages = Arrays.asList(wordsArray);
        return this;
    }
    public BookEditor setSummaryDescription(String summaryDescription) {
        this.summaryDescription = summaryDescription;
        return this;
    }

    public BookEditor setReviews(String reviews) {
        Map<String, String> reviewstmp = new HashMap<>();
        String[] lines = reviews.split("\n");
        for (String line : lines) {
            String[] parts = line.split(":\\s", 2);
            if (parts.length == 2) {
                String author = parts[0];
                String description = parts[1];
                reviewstmp.put(author, description);
            }
        }
        this.reviews = reviewstmp;
        return this;
    }

    public BookEditor setEdition(String edition) {
        this.edition = edition;
        return this;
    }

    public BookEditor setEditions(String editions) {
        String[] wordsArray = editions.split(",\\s*");
        this.editions = Arrays.asList(wordsArray);
        return this;
    }
    public BookEditor setFormat(Format format) {
        this.format = format;
        return this;
    }

    public BookEditor setSeries(String series) {
        String[] wordsArray = series.split(",\\s*");
        this.series = Arrays.asList(wordsArray);
        return this;
    }

    public BookEditor setPart(String part) {
        this.part = part;
        return this;
    }

    public BookEditor setAward(String awards) {
        String[] wordsArray = awards.split(",\\s*");
        this.award = Arrays.asList(wordsArray);
        return this;
    }

    public BookEditor setTags(String tags) {
        String[] wordsArray = tags.split(",\\s*");
        this.tags = Arrays.asList(wordsArray);
        return this;
    }

    public BookEditor setRecommendationAndRelated(String recommendationAndRelated) {
        String[] wordsArray = recommendationAndRelated.split(",\\s*");
        this.recommendationAndRelated = Arrays.asList(wordsArray);
        return this;
    }

    public BookEditor setCopyrightInfo(String copyrightInfo) {
        this.copyrightInfo = copyrightInfo;
        return this;
    }

    public BookEditor setAdditionalMaterials(String additionalMaterials) {
        this.additionalMaterials = additionalMaterials;
        return this;
    }

    public BookEditor setUsageHistory(String usageHistoryString) {
        this.usageHistory = usageHistoryString;
        return this;
    }

    public BookEditor setDonor(String donor) {
        this.donor = donor;
        return this;
    }

    public BookEditor setReaderNotes(String readerNotesString) {
        Map<String, String> notes = new HashMap<>();
        String[] lines = readerNotesString.split("\n");
        for (String line : lines) {
            String[] parts = line.split(":\\s", 2);
            if (parts.length == 2) {
                String author = parts[0];
                String description = parts[1];
                notes.put(author, description);
            }
        }
        this.readerNotes = notes;
        return this;
    }
    @Override
    public Book build() {
        return new Book(electronicVersion, title, author, isInTheLibrary, isbn, publisher, publicationDate, genre,
                numberOfPages, isAvailable, condition, checker, user, language,
                availableLanguages, summaryDescription, reviews, edition, editions, format, series,
                part, award, tags, recommendationAndRelated, copyrightInfo, additionalMaterials,
                 donor, usageHistory, readerNotes);
    }
}
