package com.example.project;

import java.io.Serializable;
import java.util.ArrayList;

public class ISBN implements Serializable {
    // 978-3-16-148410-0
    int prefix;
    int registrationGroupElement;
    int registrant;
    int publication;
    int checkDigit;
    public ISBN(String isbn){
        String s = "";
        ArrayList<Integer> arr =new ArrayList<>();
        for (int i = 0; i < isbn.length(); i++) {
            if(isbn.charAt(i) != '-'){
                s += isbn.charAt(i);
            }else{
                arr.add(Integer.parseInt(s));
                s = "";
            }
        }
        arr.add(Integer.parseInt(s));
        prefix = arr.get(0);
        registrationGroupElement = arr.get(1);
        registrant = arr.get(2);
        publication = arr.get(3);
        checkDigit = arr.get(4);
    }
    @Override
    public String toString(){
        return prefix+registrationGroupElement+registrant+publication+checkDigit+"";
    }
}
