package com.example.project;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.*;
import java.util.Objects;

public class LogInController {
    @FXML
    private PasswordField Password;
    @FXML
    private TextField Username;
    @FXML
    protected void LoginButtonClicked() throws IOException {
        File file = new File("Uproject", Username.getText() + ".prs");
        Person prs = null;
        if(Username.getText().trim().isBlank()){
            displayErrorMessage("Fill Username field!");
        }else if (file.exists()) {
            try (FileInputStream fileIn = new FileInputStream(file);
                 ObjectInputStream objectIn = new ObjectInputStream(fileIn)) {
                prs = (Person) objectIn.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
            assert prs != null;
            if (Objects.equals(prs.getPassword(), Password.getText())) {
                HelloApplication.switchScene("User.fxml");
            } else {
                displayErrorMessage("Wrong Password!");
            }
        } else {
            displayErrorMessage("User doesn't exist!");
        }
    }
    @FXML
    protected void backToMain() throws IOException {
        HelloApplication.switchScene("Main.fxml");
    }
    @FXML
    protected void Admin() throws IOException{
        HelloApplication.switchScene("Admin.fxml");
    }
    @FXML
    protected void Staff() throws IOException{
        HelloApplication.switchScene("Staff.fxml");
    }

    private void displayErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Exception!");
        alert.setHeaderText("Exception!");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
