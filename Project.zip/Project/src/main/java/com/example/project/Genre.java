package com.example.project;

public enum Genre {
    Literary_Fiction, Mystery, Thriller, Science_Fiction, Fantasy, Romance, Historical_Fiction, Horror, Poetry, Drama,
    Childrens_Literature, Non_Fiction, Other
}
