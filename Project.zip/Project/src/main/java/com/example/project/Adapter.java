package com.example.project;

public class Adapter implements BookInterface {
    private EBookOpener eBookOpener;

    public Adapter(EBookOpener eBookOpener) {
        this.eBookOpener = eBookOpener;
    }

    @Override
    public void execute(String filepath) {
        eBookOpener.open(filepath);
    }
}
