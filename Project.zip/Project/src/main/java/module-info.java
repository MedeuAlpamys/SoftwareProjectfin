module com.example.project {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.net.http;
    requires java.desktop; // Explicitly require java.desktop

    opens com.example.project to javafx.fxml;
    exports com.example.project;
}
